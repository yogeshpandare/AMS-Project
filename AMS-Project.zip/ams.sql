-- MySQL dump 10.13  Distrib 5.1.49, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: ams
-- ------------------------------------------------------
-- Server version	5.1.49-1ubuntu8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AMS`
--

DROP TABLE IF EXISTS `AMS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AMS` (
  `TRANS_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PMT_TO` varchar(50) DEFAULT NULL,
  `PMT_FROM` varchar(50) DEFAULT NULL,
  `PAY_REC` varchar(10) DEFAULT NULL,
  `COA` varchar(25) DEFAULT NULL,
  `PMT_DATE` date DEFAULT NULL,
  `AMT` double(8,3) DEFAULT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`TRANS_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AMS`
--

LOCK TABLES `AMS` WRITE;
/*!40000 ALTER TABLE `AMS` DISABLE KEYS */;
INSERT INTO `AMS` VALUES (1,'ABC Company','XYZ Company','Pay','Misc','2014-08-04',582.620,'Miscellaneous Expenses'),(2,'Star Trek Company','ABC Company','Pay','Travel','2014-11-12',3112.000,'Travel Expenses'),(3,'Star Trek Company','ABC Company','Pay','Travel','2014-11-16',1000.000,'Travel Expenses'),(4,'Red Hat Company','ABC Company','Pay','Supplies','2014-10-08',19234.340,'Stationary Supplies'),(5,'Snow Tunes Company','ABC Company','Pay','Supplies','2014-11-18',1294.000,'Records Supplies');
/*!40000 ALTER TABLE `AMS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEPARTMENT`
--

DROP TABLE IF EXISTS `DEPARTMENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEPARTMENT` (
  `DEP_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DEPT` varchar(50) DEFAULT NULL,
  `COMPANY` varchar(50) DEFAULT NULL,
  `ADD_1` varchar(50) DEFAULT NULL,
  `CITY` varchar(50) DEFAULT NULL,
  `STATE` varchar(5) DEFAULT NULL,
  `ZIPCODE` varchar(10) DEFAULT NULL,
  `COUNTRY` varchar(10) DEFAULT NULL,
  `PHONE` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`DEP_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1002 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEPARTMENT`
--

LOCK TABLES `DEPARTMENT` WRITE;
/*!40000 ALTER TABLE `DEPARTMENT` DISABLE KEYS */;
INSERT INTO `DEPARTMENT` VALUES (1000,'Accounts','ABC Company','25W 34 st Suite 45','New York ','NY','10001','US','231-345-7777'),(1001,'Sales','XYZ Company','121 Town Sq, suite 405','Jersey City','NJ','07863','US','654-315-7986');
/*!40000 ALTER TABLE `DEPARTMENT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-11-28 15:31:13
