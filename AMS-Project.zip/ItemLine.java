package excelParser;

public class ItemLine {
	public int quantity;
	public String description;
	public double unitPrice;
	
}
