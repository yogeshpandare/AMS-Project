<?php
	include "/libchart/libchart/classes/libchart.php";
	include "dbconnect.php";
	header("Content-type: image/png");
	
	$chart = new PieChart(700, 360);

	$dataSet = new XYDataSet();
	
	$sql = "SELECT * FROM AMS";
	$sqlR =  mysql_query($sql);

	while($row = mysql_fetch_assoc($sqlR))
	{
		$dataSet->addPoint(new Point('"To :'.$row['PMT_TO'].'-'.$row['COA'].' ('.$row['AMT'].')"', $row['AMT']));
	}	
	
	/*$dataSet->addPoint(new Point("Supplies (20528.34)", 20528.34));
	
	$dataSet->addPoint(new Point("Travel (4112)", 4112));
	
	$dataSet->addPoint(new Point("Misc (582.620)", 582.620));*/
	
	$chart->setDataSet($dataSet);

	$chart->setTitle("Chart of Accounts");
	$chart->render();
?>

