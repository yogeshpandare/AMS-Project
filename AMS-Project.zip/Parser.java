package excelParser;
import java.io.File;
import java.io.FileInputStream;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Parser {

	private static XSSFSheet openSheet(String fileName) throws Exception
	{
		FileInputStream file = new FileInputStream(new File(fileName));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0); // Maybe I can make an overloaded version of this method that allows selection of sheets?
		return sheet;
	}
	
	protected static XSSFCell findCell(String fileName, int row, int col) throws Exception // Row 1 and Column A are both 0; it counts up from there.
	{
		XSSFSheet sheet = openSheet(fileName);
		XSSFRow selectedRow = sheet.getRow(row); // Value will be set in the upcoming FOR loop
		XSSFCell cell = selectedRow.getCell(col); // Value will be set in the upcoming FOR loop
		return cell;
	}
	
	protected static int countItemRows(String fileName)
	{
		try
		{
			int rowNum = 20;
			XSSFSheet sheet = openSheet(fileName);
			XSSFRow selectedRow = sheet.getRow(rowNum);
			XSSFCell cell;
			int counter = 0;
			boolean quantity, description, unit; // These are flags to see whether the cells are empty.  All three must be empty for the while loop to end.
			do
			{
//				System.out.println("Checking row " + (rowNum  + 1));
				cell = selectedRow.getCell(1);
				if(cell.getCellType() != Cell.CELL_TYPE_NUMERIC)
					quantity = true;
				else
					quantity = false;
				
				cell = selectedRow.getCell(2);
				if(cell.getStringCellValue().equals(""))
					description = true;
				else
					description = false;
				
				cell = selectedRow.getCell(8);
				if(cell.getCellType() != Cell.CELL_TYPE_NUMERIC)
					unit = true;
				else
					unit = false;
				
				if(quantity == false || description == false || unit == false)
					counter++;
				
				rowNum++;
				selectedRow = sheet.getRow(rowNum);
			} while(quantity == false || description == false || unit == false);
			return counter;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return -1; // -1 is an impossible number of rows, so I am using it as an error value
		}
	}
	
	public static String getFrom(String fileName)
	{
		try
		{
			XSSFCell cell = findCell(fileName, 2, 1);
			return cell.getStringCellValue();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}

	public static String getTo(String fileName)
	{
		try
		{
			XSSFCell cell = findCell(fileName, 7, 1);
			return cell.getStringCellValue();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}
	
	public static String getDesc(String fileName)
	{
		try
		{
			XSSFCell cell = findCell(fileName, 20, 2);
			return cell.getStringCellValue();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
	}

	public static double getAmt(String fileName)
	{
		try
		{
			XSSFCell cell = findCell(fileName, 20, 8);
			return cell.getNumericCellValue();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	
	public static Date getDate(String fileName)
	{
		Date date = new Date();
		try
		{
			XSSFCell cell = findCell(fileName, 8, 8);
			return cell.getDateCellValue();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return date;
		}
	}
	public static ItemLine[] getItems(String fileName)
	{
		int numRows = countItemRows(fileName);
		ItemLine[] array = new ItemLine[numRows];
		int currentRow = 20;
		XSSFCell cell;
		try
		{
			for(int i = 0; i < numRows; i++)
			{
				cell = findCell(fileName, currentRow, 1);
				array[i].quantity = (int)cell.getNumericCellValue();
				cell = findCell(fileName, currentRow, 2);
				array[i].description = cell.getStringCellValue();
				cell = findCell(fileName, currentRow, 8);
				array[i].unitPrice = cell.getNumericCellValue();
				currentRow++;
				System.out.format("%s,%s,%s,\n",array[i].quantity,array[i].description,array[i].unitPrice);
			}
		 
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			for(int i = 0; i < numRows; i++)
			{
				array[i].quantity = 0;
				array[i].description = "An error has occurred.";
				array[i].unitPrice = 0;
			
			}
			
		}
		return array;
	}
	
public static void main(String[] args) 
{
		// TODO Auto-generated method stub
String frm = getFrom("test.xlsx");
String desc = getDesc("test.xlsx");
double amt = getAmt("test.xlsx");
Date dt = getDate("test.xlsx");
System.out.format("%s,%s,%s,%s\n",frm,desc,amt,dt);
//ItemLine[] ar1 = getItems("test.xlsx");
/*for(int i=0; i<ar1.length; i++)	
{System.out.format("%s,%s,%s",ar1[i].quantity,ar1[i].description,ar1[i].unitPrice);
	}*/
}

}
