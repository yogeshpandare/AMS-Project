<?php
	include "/libchart/libchart/classes/libchart.php";
	include "dbconnect.php";

	header("Content-type: image/png");
	
	$chart = new VerticalBarChart(700,350);
	
	$dataSet = new XYDataSet();

	$sql = "SELECT Sum(AMT) AS AMT,PMT_DATE FROM AMS WHERE PMT_FROM='ABC COMPANY' and PAY_REC='PAY' Group by PMT_DATE order by PMT_DATE";
	$sqlR =  mysql_query($sql);

	while($row = mysql_fetch_assoc($sqlR))
	{
		$dataSet->addPoint(new Point($row['PMT_DATE'], $row['AMT']));
	}

	/*$dataSet->addPoint(new Point("2014-11-12", 3112));
	$dataSet->addPoint(new Point("2014-11-16", 1000));
	$dataSet->addPoint(new Point("2014-10-08", 19234.34));
	$dataSet->addPoint(new Point("2014-11-18", 1294));*/
	$chart->setDataSet($dataSet);
	
	$chart->setTitle("Expenses vs Dates");
	$chart->render();
?>

