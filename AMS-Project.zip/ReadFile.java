package excelParser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	String pmtfrom = Parser.getFrom("test.xlsx");
	String pmtto = Parser.getTo("test.xlsx");
	String payrec = "Pay";
	  {
      	if(pmtfrom.startsWith("ABC")==true)
      		payrec="Pay";
      		else
      			payrec="Rec";
      }
	String coa = "Misc";
	
	
	String description = Parser.getDesc("test.xlsx");
	double amount = Parser.getAmt("test.xlsx");
	{
	if (description.startsWith("Travel")==true)
	coa = "Travel";
	else if (description.startsWith("Misc")==true)
		coa = "Misc";
	else if (description.endsWith("Supplies")==true)
		coa = "Supplies";
	else 
		coa = "Other";
	}
	Date dt = Parser.getDate("test.xlsx");
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	String pmtdate= dateFormat.format(dt);
	//System.out.format("%s,%s,%s,%s,%s\n",frm,to,desc,amt,dt2);
	 try
	    {
	      // create our mysql database connection
	    	String jdbcDriver = "com.mysql.jdbc.Driver";
	    	  String dbURL = "jdbc:mysql://localhost:3306/AMS";
	    	  String user = "root";
	    	  String password = "123456";
	    //	 boolean isStatementFree = true;
	    	 Connection conn = null;
	   
	      Class.forName(jdbcDriver);
	      try
	      {
	       conn = DriverManager.getConnection(dbURL,user,password);
	      } catch (SQLException e1)
	      {
	          System.err.println("Connection Failed! ");
	          System.err.println(e1.getMessage());
	        }
	     // String query = "SELECT * FROM AMS";
	      String query1 = "INSERT INTO AMS(PMT_TO,PMT_FROM,PAY_REC,COA,PMT_DATE,AMT,DESCRIPTION) VALUES('" + pmtto +"','"+pmtfrom+"','"+payrec+"','"+coa+"','"+pmtdate+"','"+amount+"','"+description+"');";
	       Statement st = conn.createStatement();
	      st.executeUpdate(query1);
	      System.out.println("Connection Sucessful");
	  
	      // our SQL SELECT query. 
	      // if you only need a few columns, specify them by name instead of using "*"
	     
	      // create the java statement
	      
	  
	      // execute the query, and get a java resultset
	     
	      st.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    }
	
	}
}