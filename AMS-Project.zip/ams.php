<!DOCTYPE html>
<html>
<body style="background-color:#e8f4f8">
<h2> <center> Account Managment System </center></h2>
<br>  </br>

</body>
</html>

<?php
	include 'dbconnect.php';


	// showing table from AMS Table 
	$sqlams = "SELECT * FROM AMS order by TRANS_ID";
	$sqlResrams =  mysql_query($sqlams);
	
	
	echo "<h3 style='text-align:center'><em>Payment Information</em></h3>";
	echo '<table border = 0.5 align = center>';
	echo '<tr><td><b>ID</b></td><td><b>Payment To</b></td><td><b>Payment From</b></td><td><b>Pay_Rec</b></td><td><b>Chart Of Accounts</b></td><td><b>Date</b></td><td><b>Amount</b></td><td><b>Description</b></td></tr>';
	
	while($row = mysql_fetch_array($sqlResrams))
	{
		echo '<tr><td>'.$row['TRANS_ID'].'</td><td>'.$row['PMT_TO'].'</td><td>'.$row['PMT_FROM'].'</td><td>'.$row['PAY_REC'].'</td><td>'.$row['COA'].'</td><td>'.$row['PMT_DATE'].'</td><td>'.$row['AMT'].'</td><td>'.$row['DESCRIPTION'].'</td></tr>';
		
	}echo '</table>';

	
	// showing table from Department Table 

	$sqldpt = "SELECT * FROM DEPARTMENT";
	$sqlResrdpt =  mysql_query($sqldpt);

	echo "<br/><br/><h3 style='text-align:center'><em>Address Information</em></h3>";
	echo '<table border = 0 align = center>';
	echo '<tr><td><b>Dept ID</b></td><td><b>Department</b></td><td><b>Company</b></td><td><b>Address</b></td><td><b>City</b></td><td><b>State</b></td><td><b>Postal Code</b></td><td><b>Country</b></td><td><b>Phone</b></td></tr>';
	
	while($row = mysql_fetch_array($sqlResrdpt))
	{
		
		echo '<tr><td>'.$row['DEP_ID'].'</td><td>'.$row['DEPT'].'</td><td>'.$row['COMPANY'].'</td><td>'.$row['ADD_1'].'</td><td>'.$row['CITY'].'</td><td>'.$row['STATE'].'</td><td>'.$row['ZIPCODE'].'</td><td>'.$row['COUNTRY'].'</td><td>'.$row['PHONE'].'</td></tr>';
		
	}	echo '</table>';

?>



