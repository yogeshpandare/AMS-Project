<?php
$conn  = mysql_connect('127.0.0.1:3306','root','123456');
if(!$conn)
{
die('Connection Failed'.mysql_error());
}
//echo '';	
mysql_select_db('AMS',$conn) or die('Connection failed');

?>
